#include "automata_constructor.h"

int main(int argc, char *argv[]){

	WriteFile(argc, argv);

	return 0;
}
