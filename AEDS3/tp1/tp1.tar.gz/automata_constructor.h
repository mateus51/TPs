#ifndef AUTOMATA_CONSTRUCTOR_H
#define AUTOMATA_CONSTRUCTOR_H

#include <string.h>
#include "io.h"

int* preKMP(char *search_string);

void WriteFile(int argc, char *argv[]);

#endif
