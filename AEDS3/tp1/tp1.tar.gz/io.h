#ifndef IO_H
#define IO_H

#include <stdio.h>
#include <stdlib.h>

char* ParseParams(int argc, char *argv[]);

#endif
