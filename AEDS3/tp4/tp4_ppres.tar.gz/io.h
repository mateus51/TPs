#ifndef IO_H
#define IO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE* ParseParams(int argc, char *argv[]);

#endif
