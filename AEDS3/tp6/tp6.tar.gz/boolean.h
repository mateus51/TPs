#ifndef __BOOLEAN_H__
#define __BOOLEAN_H__
typedef char boolean;
#define TRUE 1
#define FALSE 0
#endif
