#ifndef IO_H
#define IO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "boolean.h"

#define LINE_MAX_SIZE 20

FILE* ParseParams(int argc, char *argv[]);

#endif
