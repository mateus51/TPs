#ifndef BOOLEAN_TYPE
#define BOOLEAN_TYPE

// boolean type
typedef char boolean;
#define TRUE 1
#define FALSE 0

#endif
