#include "kemeny_young.h"

int main(int argc, char *argv[]){

	KemenyYoung(argc, argv);

	return 0;
}
