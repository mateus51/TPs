package org.neoframework.bookstore.service;

import org.neoframework.bookstore.bean.Uf;

import br.com.linkcom.neo.service.GenericService;

public class UfService extends GenericService<Uf> {

}
