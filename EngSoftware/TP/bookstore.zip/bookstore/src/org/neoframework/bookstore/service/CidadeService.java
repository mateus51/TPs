package org.neoframework.bookstore.service;

import org.neoframework.bookstore.bean.Cidade;

import br.com.linkcom.neo.service.GenericService;

public class CidadeService extends GenericService<Cidade> {

}
