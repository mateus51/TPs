package org.neoframework.bookstore.service;

import org.neoframework.bookstore.bean.Genero;

import br.com.linkcom.neo.service.GenericService;

public class GeneroService extends GenericService<Genero> {

}
