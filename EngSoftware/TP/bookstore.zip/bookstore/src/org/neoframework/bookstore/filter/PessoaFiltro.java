package org.neoframework.bookstore.filter;

import br.com.linkcom.neo.controller.crud.FiltroListagem;

public class PessoaFiltro extends FiltroListagem {

}
