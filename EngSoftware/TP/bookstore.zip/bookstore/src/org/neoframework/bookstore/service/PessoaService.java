package org.neoframework.bookstore.service;

import org.neoframework.bookstore.bean.Pessoa;

import br.com.linkcom.neo.service.GenericService;

public class PessoaService extends GenericService<Pessoa> {

}
