package org.neoframework.bookstore.service;

import org.neoframework.bookstore.bean.Tipoparticipantelivro;

import br.com.linkcom.neo.service.GenericService;

public class TipoparticipantelivroService extends GenericService<Tipoparticipantelivro> {

}
