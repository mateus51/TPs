package org.neoframework.bookstore.dao;

import org.neoframework.bookstore.bean.Tipoparticipantelivro;

import br.com.linkcom.neo.persistence.GenericDAO;

public class TipoparticipantelivroDAO extends GenericDAO<Tipoparticipantelivro> {

}
