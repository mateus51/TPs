package org.neoframework.bookstore.dao;

import org.neoframework.bookstore.bean.Pessoa;

import br.com.linkcom.neo.persistence.GenericDAO;

public class PessoaDAO extends GenericDAO<Pessoa> {

}
