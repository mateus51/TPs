package org.neoframework.bookstore.dao;

import org.neoframework.bookstore.bean.Uf;

import br.com.linkcom.neo.persistence.GenericDAO;

public class UfDAO extends GenericDAO<Uf> {

}
