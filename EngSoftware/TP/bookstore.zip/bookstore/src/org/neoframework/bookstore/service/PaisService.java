package org.neoframework.bookstore.service;

import org.neoframework.bookstore.bean.Pais;

import br.com.linkcom.neo.service.GenericService;

public class PaisService extends GenericService<Pais> {

}
