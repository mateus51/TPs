package org.neoframework.bookstore.dao;

import org.neoframework.bookstore.bean.Genero;

import br.com.linkcom.neo.persistence.GenericDAO;

public class GeneroDAO extends GenericDAO<Genero> {

}
