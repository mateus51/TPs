#include <pthread.h>

void start_signal_listener();
