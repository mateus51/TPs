// Get the current time with gettimeofday()
// and return its value in seconds
double get_time();
