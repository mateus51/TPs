#include <stdlib.h>

#include "socket.h"
#include "time.h"
#include "io.h"

void send_file(struct HostInfo *info);
