#include <sys/time.h>
#include <stdlib.h>

double get_time();
