#ifndef IO_H
#define	IO_H

void LimpaString(char *string, int tam);

#endif
