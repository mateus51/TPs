#ifndef TP2_H
#define TP2_H

void mysettimer(int milisegundos);
void timer_handler(int signum);
void mysethandler(void);

#endif
