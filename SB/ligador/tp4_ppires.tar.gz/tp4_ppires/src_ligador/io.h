#ifndef __IO_H__
#define __IO_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>


void GetArgs(int argc, char *argv[]);


#endif
