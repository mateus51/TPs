package Planilha;

interface Observer {
	
	public void update(Subject s);
	
}
